## Запуск проекта
1. Создать БД в PostgreSQL
2. Установить зависимости: `pip install -r requirements.txt`
3. Миграции: `python manage.py migrate`
4. Запуск: `python manage.py runserver`